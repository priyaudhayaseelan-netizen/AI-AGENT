import {
  Trophy,
  Flame,
  HelpCircle,
  CheckCircle2,
  Target,
  RotateCcw,
  Sparkles,
  ArrowRight,
  BookOpen,
} from "lucide-react";
import type { Difficulty, QuizStats } from "../types";

interface ResultsScreenProps {
  stats: QuizStats;
  topic: string;
  difficulty: Difficulty;
  onPlayAgain: () => void;
  onChangeTopic: () => void;
}

export function ResultsScreen({
  stats,
  topic,
  difficulty,
  onPlayAgain,
  onChangeTopic,
}: ResultsScreenProps) {
  const accuracy =
    stats.totalQuestions > 0
      ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100)
      : 0;

  // Evaluative messaging based on performance
  let performanceTitle = "Quiz Complete!";
  let performanceSubtitle = "Great effort! Knowledge grows with every question.";
  if (stats.bestStreak >= 10) {
    performanceTitle = "Trivia Grandmaster!";
    performanceSubtitle = "Astonishing focus and domain mastery!";
  } else if (stats.bestStreak >= 5) {
    performanceTitle = "Streak Master!";
    performanceSubtitle = "Impressive streak! You truly know your stuff.";
  } else if (stats.bestStreak >= 3) {
    performanceTitle = "Solid Run!";
    performanceSubtitle = "Good momentum and sharp intuition.";
  }

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8 sm:py-12">
      {/* Header Badge & Title */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 shadow-xl shadow-indigo-600/30 mb-5 relative">
          <Trophy className="w-10 h-10 text-amber-300" />
          <div className="absolute -top-1 -right-1 p-1.5 bg-slate-950 rounded-full border border-slate-800">
            <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300" />
          </div>
        </div>

        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-2">
          {performanceTitle}
        </h1>
        <p className="text-slate-300 text-sm sm:text-base max-w-md mx-auto">
          {performanceSubtitle}
        </p>

        {/* Topic & Difficulty Tag */}
        <div className="inline-flex items-center gap-2 mt-4 px-3.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-300">
          <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
          <span className="font-semibold text-white truncate max-w-[180px]">{topic}</span>
          <span className="text-slate-500">•</span>
          <span className="capitalize text-indigo-300 font-medium">{difficulty}</span>
        </div>
      </div>

      {/* Main Results Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm relative overflow-hidden mb-6">
        {/* Glow accents */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-6">
          {/* Best Streak Hero Highlight */}
          <div className="p-5 sm:p-6 rounded-xl bg-gradient-to-b from-indigo-950/60 to-purple-950/40 border border-indigo-500/40 text-center relative overflow-hidden">
            <div className="flex items-center justify-center gap-1.5 text-xs sm:text-sm font-semibold text-amber-300 mb-1">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
              <span>Best Streak Record</span>
            </div>
            <div className="text-4xl sm:text-6xl font-black text-white tracking-tight">
              {stats.bestStreak}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {stats.bestStreak === 1
                ? "1 consecutive correct answer"
                : `${stats.bestStreak} consecutive correct answers`}
            </p>
          </div>

          {/* Stats Grid: Total Questions, Correct Answers, Accuracy */}
          <div className="grid grid-cols-3 gap-3 sm:gap-4">
            {/* Total Questions */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <div className="flex items-center justify-center gap-1 text-xs font-semibold text-slate-400 mb-1">
                <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
                <span>Total</span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-white">
                {stats.totalQuestions}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Questions</div>
            </div>

            {/* Correct Answers */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <div className="flex items-center justify-center gap-1 text-xs font-semibold text-slate-400 mb-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>Correct</span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400">
                {stats.correctAnswers}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Answers</div>
            </div>

            {/* Accuracy Percentage */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 text-center">
              <div className="flex items-center justify-center gap-1 text-xs font-semibold text-slate-400 mb-1">
                <Target className="w-3.5 h-3.5 text-indigo-400" />
                <span>Accuracy</span>
              </div>
              <div className="text-2xl sm:text-3xl font-extrabold text-indigo-300">
                {accuracy}%
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">Success Rate</div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons: Play Again & Change Topic */}
      <div className="space-y-3">
        {/* Play Again (same topic/difficulty) */}
        <button
          type="button"
          id="play-again-btn"
          onClick={onPlayAgain}
          className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:via-indigo-500 hover:to-purple-500 text-white font-bold text-base sm:text-lg shadow-lg shadow-indigo-900/30 flex items-center justify-center gap-2.5 transition-all transform active:scale-[0.99] cursor-pointer"
        >
          <RotateCcw className="w-5 h-5" />
          <span>Play Again on "{topic}"</span>
        </button>

        {/* Change Topic Button */}
        <button
          type="button"
          id="change-topic-btn"
          onClick={onChangeTopic}
          className="w-full py-3.5 px-6 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold text-sm sm:text-base flex items-center justify-center gap-2 transition-all cursor-pointer"
        >
          <span>Choose Another Topic</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

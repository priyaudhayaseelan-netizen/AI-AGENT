import { useState } from "react";
import { Flame, Sparkles, ArrowRight, Brain, Trophy, Zap, AlertCircle } from "lucide-react";
import type { Difficulty } from "../types";

interface HomeScreenProps {
  onStartQuiz: (topic: string, difficulty: Difficulty) => void;
  isLoading: boolean;
  error: string | null;
  onClearError: () => void;
  bestOverallStreak: number;
}

const EXAMPLE_TOPICS = [
  "Space Exploration",
  "World Capitals",
  "Ancient Rome",
  "Computer Science",
  "Marine Biology",
  "Classic Cinema",
  "Human Anatomy",
  "Greek Mythology",
];

export function HomeScreen({
  onStartQuiz,
  isLoading,
  error,
  onClearError,
  bestOverallStreak,
}: HomeScreenProps) {
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [validationError, setValidationError] = useState<string | null>(null);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!topic.trim()) {
      setValidationError("Please enter a topic to begin the quiz.");
      return;
    }
    setValidationError(null);
    onClearError();
    onStartQuiz(topic.trim(), difficulty);
  };

  const handleSelectExample = (exampleTopic: string) => {
    setTopic(exampleTopic);
    setValidationError(null);
    onClearError();
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8 sm:py-12">
      {/* App Header */}
      <div className="text-center mb-8 sm:mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-indigo-950/80 border border-indigo-500/30 text-indigo-300 text-xs sm:text-sm font-medium mb-4 shadow-sm">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>Powered by Gemini AI</span>
        </div>

        <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white mb-3">
          AI Streak Quiz
        </h1>
        <p className="text-slate-300 text-base sm:text-lg max-w-lg mx-auto leading-relaxed">
          Pick any topic, set your difficulty, and answer dynamic AI questions to build your longest streak.
        </p>

        {bestOverallStreak > 0 && (
          <div className="inline-flex items-center gap-2 mt-4 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-sm font-semibold">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Session Record: {bestOverallStreak} {bestOverallStreak === 1 ? "streak" : "streaks"}</span>
          </div>
        )}
      </div>

      {/* Main Setup Card */}
      <div className="bg-slate-900/90 border border-slate-800/80 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm relative overflow-hidden">
        {/* Subtle decorative gradient glow behind */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-indigo-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none" />

        <form onSubmit={handleSubmit} className="space-y-6 relative z-10">
          {/* Topic Input */}
          <div>
            <label
              htmlFor="topic-input"
              className="block text-sm font-semibold text-slate-200 mb-2"
            >
              Quiz Topic
            </label>
            <div className="relative">
              <input
                id="topic-input"
                type="text"
                value={topic}
                onChange={(e) => {
                  setTopic(e.target.value);
                  if (validationError) setValidationError(null);
                  if (error) onClearError();
                }}
                placeholder="e.g., Quantum Physics, 90s Hip Hop, World War II..."
                disabled={isLoading}
                maxLength={80}
                className="w-full px-4 py-3.5 rounded-xl bg-slate-950 border border-slate-700/80 text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all text-base sm:text-lg shadow-inner disabled:opacity-50"
              />
              {topic.length > 0 && (
                <button
                  type="button"
                  onClick={() => setTopic("")}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800/60"
                >
                  Clear
                </button>
              )}
            </div>
            {validationError && (
              <p className="mt-2 text-sm text-rose-400 flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4" />
                {validationError}
              </p>
            )}
          </div>

          {/* Difficulty Dropdown / Selector */}
          <div>
            <label
              htmlFor="difficulty-select"
              className="block text-sm font-semibold text-slate-200 mb-2"
            >
              Difficulty Level
            </label>
            <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
              {(
                [
                  { id: "easy", label: "Easy", desc: "Foundational & clear", color: "emerald" },
                  { id: "medium", label: "Medium", desc: "Balanced trivia", color: "amber" },
                  { id: "hard", label: "Hard", desc: "Deep & nuanced", color: "rose" },
                ] as const
              ).map((lvl) => {
                const isSelected = difficulty === lvl.id;
                return (
                  <button
                    key={lvl.id}
                    type="button"
                    id={`difficulty-${lvl.id}`}
                    onClick={() => setDifficulty(lvl.id)}
                    disabled={isLoading}
                    className={`py-3 px-3 sm:px-4 rounded-xl border text-center transition-all ${
                      isSelected
                        ? "bg-gradient-to-b from-indigo-900/60 to-purple-900/50 border-indigo-400 text-white shadow-lg ring-1 ring-indigo-400"
                        : "bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                    }`}
                  >
                    <div className="font-bold text-sm sm:text-base capitalize">
                      {lvl.label}
                    </div>
                    <div className="text-[11px] sm:text-xs text-slate-400 mt-0.5 hidden sm:block">
                      {lvl.desc}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Example Topic Buttons */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                Popular Topics
              </span>
              <span className="text-xs text-slate-400">Click to select</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {EXAMPLE_TOPICS.map((t) => (
                <button
                  key={t}
                  type="button"
                  id={`example-topic-${t.toLowerCase().replace(/\s+/g, "-")}`}
                  onClick={() => handleSelectExample(t)}
                  disabled={isLoading}
                  className={`text-xs sm:text-sm px-3 py-1.5 rounded-lg border transition-all ${
                    topic.toLowerCase() === t.toLowerCase()
                      ? "bg-indigo-600 border-indigo-500 text-white font-medium"
                      : "bg-slate-950/70 border-slate-800 text-slate-300 hover:border-indigo-500/50 hover:bg-slate-800/60 hover:text-white"
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>

          {/* Error Banner */}
          {error && (
            <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-800/80 text-rose-200 text-sm flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-medium">Failed to generate question</p>
                <p className="text-xs text-rose-300/90 mt-0.5">{error}</p>
              </div>
            </div>
          )}

          {/* Start Quiz Button */}
          <button
            type="submit"
            id="start-quiz-btn"
            disabled={isLoading}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:via-indigo-500 hover:to-purple-500 text-white font-bold text-base sm:text-lg shadow-lg shadow-indigo-900/30 flex items-center justify-center gap-3 transition-all transform active:scale-[0.99] disabled:opacity-60 disabled:cursor-not-allowed cursor-pointer"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Generating Question with Gemini...</span>
              </>
            ) : (
              <>
                <Flame className="w-5 h-5 text-amber-300 fill-amber-300" />
                <span>Start Quiz</span>
                <ArrowRight className="w-5 h-5" />
              </>
            )}
          </button>
        </form>
      </div>

      {/* Educational Features Highlights */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 sm:gap-4 mt-8">
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800/60 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
            <Zap className="w-5 h-5" />
          </div>
          <div>
            <div className="text-white text-xs sm:text-sm font-semibold">Streak Counter</div>
            <div className="text-slate-400 text-xs">Test your consistency</div>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800/60 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="text-white text-xs sm:text-sm font-semibold">Instant Explanations</div>
            <div className="text-slate-400 text-xs">Learn when you stumble</div>
          </div>
        </div>
        <div className="p-4 rounded-xl bg-slate-900/50 border border-slate-800/60 flex items-center gap-3">
          <div className="p-2 rounded-lg bg-indigo-500/10 text-indigo-400">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-white text-xs sm:text-sm font-semibold">Endless Questions</div>
            <div className="text-slate-400 text-xs">Unique questions every round</div>
          </div>
        </div>
      </div>
    </div>
  );
}

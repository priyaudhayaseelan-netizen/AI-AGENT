import { Sparkles, Brain, Loader2 } from "lucide-react";
import type { Difficulty } from "../types";

interface LoadingCardProps {
  topic: string;
  difficulty: Difficulty;
  questionNumber: number;
}

export function LoadingCard({ topic, difficulty, questionNumber }: LoadingCardProps) {
  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-8">
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-sm relative overflow-hidden">
        {/* Animated background glow */}
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/10 via-purple-600/10 to-indigo-600/10 animate-pulse pointer-events-none" />

        {/* Header tags */}
        <div className="flex items-center justify-between gap-2 mb-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-800 text-slate-300 text-xs font-medium">
            <Brain className="w-3.5 h-3.5 text-indigo-400" />
            <span>Question #{questionNumber}</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Topic:</span>
            <span className="text-xs font-semibold text-white truncate max-w-[150px] sm:max-w-[200px]">
              {topic}
            </span>
            <span className="capitalize text-[11px] px-2 py-0.5 rounded font-medium bg-slate-800 text-indigo-300 border border-slate-700">
              {difficulty}
            </span>
          </div>
        </div>

        {/* Loading Spinner & Status */}
        <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-600/30">
              <Loader2 className="w-8 h-8 text-white animate-spin" />
            </div>
            <div className="absolute -bottom-1 -right-1 p-1 bg-slate-950 rounded-full border border-slate-800">
              <Sparkles className="w-4 h-4 text-amber-300 fill-amber-300 animate-bounce" />
            </div>
          </div>

          <div className="space-y-1.5">
            <h3 className="text-lg font-bold text-white">
              Generating Question...
            </h3>
            <p className="text-sm text-slate-400 max-w-sm">
              Gemini AI is creating a fresh <span className="text-indigo-300 font-medium capitalize">{difficulty}</span> multiple-choice question on <span className="text-indigo-300 font-medium">"{topic}"</span>.
            </p>
          </div>

          {/* Skeleton representation */}
          <div className="w-full space-y-2.5 pt-4 max-w-md">
            <div className="h-4 bg-slate-800/80 rounded-full w-4/5 mx-auto animate-pulse" />
            <div className="h-4 bg-slate-800/60 rounded-full w-3/5 mx-auto animate-pulse" />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2">
              <div className="h-10 bg-slate-800/50 rounded-xl animate-pulse" />
              <div className="h-10 bg-slate-800/50 rounded-xl animate-pulse" />
              <div className="h-10 bg-slate-800/50 rounded-xl animate-pulse" />
              <div className="h-10 bg-slate-800/50 rounded-xl animate-pulse" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState, useEffect } from "react";
import {
  Flame,
  Trophy,
  CheckCircle2,
  XCircle,
  ArrowRight,
  LogOut,
  Target,
  Sparkles,
  HelpCircle,
  AlertTriangle,
} from "lucide-react";
import type { QuizQuestion, Difficulty, QuizStats } from "../types";

interface QuizScreenProps {
  question: QuizQuestion;
  topic: string;
  difficulty: Difficulty;
  stats: QuizStats;
  questionNumber: number;
  onAnswerSubmit: (isCorrect: boolean) => void;
  onNextQuestion: () => void;
  onQuitQuiz: () => void;
  isGeneratingNext: boolean;
}

const OPTION_LETTERS = ["A", "B", "C", "D"];

export function QuizScreen({
  question,
  topic,
  difficulty,
  stats,
  questionNumber,
  onAnswerSubmit,
  onNextQuestion,
  onQuitQuiz,
  isGeneratingNext,
}: QuizScreenProps) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [showQuitConfirm, setShowQuitConfirm] = useState<boolean>(false);
  const [autoNextCountdown, setAutoNextCountdown] = useState<number | null>(null);

  // Reset state on new question
  useEffect(() => {
    setSelectedOption(null);
    setIsSubmitted(false);
    setAutoNextCountdown(null);
  }, [question]);

  const isCorrectAnswer =
    isSubmitted && selectedOption === question.correctAnswerIndex;

  const handleSubmitAnswer = () => {
    if (selectedOption === null || isSubmitted) return;

    const isCorrect = selectedOption === question.correctAnswerIndex;
    setIsSubmitted(true);
    onAnswerSubmit(isCorrect);

    // If correct: automatically generate the next question after brief celebration
    if (isCorrect) {
      setAutoNextCountdown(2);
      const timer = setTimeout(() => {
        onNextQuestion();
      }, 1500);
      return () => clearTimeout(timer);
    }
  };

  const accuracyPercent =
    stats.totalQuestions > 0
      ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100)
      : 0;

  const difficultyColors = {
    easy: "text-emerald-400 bg-emerald-950/60 border-emerald-800/80",
    medium: "text-amber-400 bg-amber-950/60 border-amber-800/80",
    hard: "text-rose-400 bg-rose-950/60 border-rose-800/80",
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-6 sm:py-8">
      {/* Top Bar: Topic, Difficulty, and Quit Button */}
      <div className="flex items-center justify-between gap-3 mb-5">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-xs text-slate-400 hidden sm:inline">Topic:</span>
          <span className="text-sm sm:text-base font-bold text-white truncate max-w-[170px] sm:max-w-[260px]">
            {topic}
          </span>
          <span
            className={`capitalize text-xs font-semibold px-2 py-0.5 rounded-full border ${
              difficultyColors[difficulty] || difficultyColors.medium
            }`}
          >
            {difficulty}
          </span>
        </div>

        <button
          type="button"
          id="quit-quiz-btn"
          onClick={() => setShowQuitConfirm(true)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-700/80 text-xs sm:text-sm font-medium text-slate-300 hover:text-rose-300 hover:border-rose-500/50 hover:bg-slate-800 transition-all"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Quit</span>
        </button>
      </div>

      {/* Stats Bar: Current Streak, Best Streak, Accuracy, Total */}
      <div className="grid grid-cols-4 gap-2 sm:gap-3 mb-6">
        {/* Current Streak with dynamic glow */}
        <div
          className={`p-2.5 sm:p-3 rounded-xl border text-center transition-all ${
            stats.currentStreak > 0
              ? "bg-gradient-to-b from-indigo-950/80 to-purple-950/80 border-indigo-500/50 shadow-md shadow-indigo-950"
              : "bg-slate-900/70 border-slate-800"
          }`}
        >
          <div className="flex items-center justify-center gap-1 text-[11px] sm:text-xs font-semibold text-slate-400">
            <Flame
              className={`w-3.5 h-3.5 ${
                stats.currentStreak > 0
                  ? "text-amber-400 fill-amber-400 animate-pulse"
                  : "text-slate-500"
              }`}
            />
            <span>Streak</span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-0.5">
            {stats.currentStreak}
          </div>
        </div>

        {/* Best Streak */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <div className="flex items-center justify-center gap-1 text-[11px] sm:text-xs font-semibold text-slate-400">
            <Trophy className="w-3.5 h-3.5 text-amber-400" />
            <span>Best</span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-300 mt-0.5">
            {stats.bestStreak}
          </div>
        </div>

        {/* Total Questions */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <div className="flex items-center justify-center gap-1 text-[11px] sm:text-xs font-semibold text-slate-400">
            <HelpCircle className="w-3.5 h-3.5 text-blue-400" />
            <span>Questions</span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-0.5">
            {stats.totalQuestions}
          </div>
        </div>

        {/* Accuracy */}
        <div className="p-2.5 sm:p-3 rounded-xl bg-slate-900/70 border border-slate-800 text-center">
          <div className="flex items-center justify-center gap-1 text-[11px] sm:text-xs font-semibold text-slate-400">
            <Target className="w-3.5 h-3.5 text-emerald-400" />
            <span>Accuracy</span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-emerald-300 mt-0.5">
            {stats.totalQuestions > 0 ? `${accuracyPercent}%` : "—"}
          </div>
        </div>
      </div>

      {/* Main Question Card */}
      <div className="bg-slate-900/95 border border-slate-800 rounded-2xl p-5 sm:p-7 shadow-2xl backdrop-blur-sm relative overflow-hidden">
        {/* Subtle accent line */}
        <div className="h-1 -mx-5 sm:-mx-7 -mt-5 sm:-mt-7 mb-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600" />

        {/* Question Counter */}
        <div className="flex items-center justify-between mb-3 text-xs text-slate-400">
          <span className="font-semibold uppercase tracking-wider text-indigo-400">
            Question #{questionNumber}
          </span>
          {isSubmitted && isCorrectAnswer && (
            <span className="inline-flex items-center gap-1 text-emerald-400 font-bold animate-bounce">
              <Sparkles className="w-3.5 h-3.5" />
              +1 Streak!
            </span>
          )}
        </div>

        {/* Question Text */}
        <h2 className="text-lg sm:text-xl font-bold text-white leading-relaxed mb-6">
          {question.question}
        </h2>

        {/* Four Answer Options */}
        <div className="space-y-3 mb-6" role="radiogroup" aria-label="Question options">
          {question.options.map((optionText, index) => {
            const isSelected = selectedOption === index;
            const isThisTheCorrectAnswer = question.correctAnswerIndex === index;

            // Compute styling based on whether submitted or not
            let optionStyles =
              "bg-slate-950/70 border-slate-800 text-slate-200 hover:border-slate-700 hover:bg-slate-800/50";
            let badgeStyles = "bg-slate-800 text-slate-400";

            if (!isSubmitted) {
              if (isSelected) {
                optionStyles =
                  "bg-indigo-950/70 border-indigo-400 text-white shadow-md ring-2 ring-indigo-500/40";
                badgeStyles = "bg-indigo-600 text-white font-bold";
              }
            } else {
              // Once submitted, reveal correct and wrong
              if (isThisTheCorrectAnswer) {
                optionStyles =
                  "bg-emerald-950/80 border-emerald-500 text-white shadow-md ring-2 ring-emerald-500/40";
                badgeStyles = "bg-emerald-600 text-white font-bold";
              } else if (isSelected && !isThisTheCorrectAnswer) {
                optionStyles =
                  "bg-rose-950/80 border-rose-500 text-rose-100 shadow-md ring-2 ring-rose-500/40";
                badgeStyles = "bg-rose-600 text-white font-bold";
              } else {
                optionStyles = "bg-slate-950/40 border-slate-800/60 text-slate-500 opacity-60";
                badgeStyles = "bg-slate-900 text-slate-600";
              }
            }

            return (
              <button
                key={index}
                type="button"
                id={`quiz-option-${index}`}
                disabled={isSubmitted}
                onClick={() => setSelectedOption(index)}
                className={`w-full p-4 rounded-xl border text-left flex items-center justify-between gap-4 transition-all cursor-pointer disabled:cursor-default ${optionStyles}`}
              >
                <div className="flex items-center gap-3.5 flex-1 min-w-0">
                  <span
                    className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-bold shrink-0 transition-colors ${badgeStyles}`}
                  >
                    {OPTION_LETTERS[index]}
                  </span>
                  <span className="text-sm sm:text-base font-medium leading-snug break-words">
                    {optionText}
                  </span>
                </div>

                {/* State Icons after submission */}
                {isSubmitted && (
                  <div className="shrink-0">
                    {isThisTheCorrectAnswer ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    ) : isSelected ? (
                      <XCircle className="w-5 h-5 text-rose-400" />
                    ) : null}
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Action Controls */}
        {!isSubmitted ? (
          <button
            type="button"
            id="submit-answer-btn"
            disabled={selectedOption === null}
            onClick={handleSubmitAnswer}
            className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:via-indigo-500 hover:to-purple-500 text-white font-bold text-base sm:text-lg shadow-lg shadow-indigo-900/30 flex items-center justify-center gap-2 transition-all transform active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
          >
            <span>Submit Answer</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        ) : (
          <div className="space-y-4">
            {/* Feedback Message */}
            {isCorrectAnswer ? (
              <div className="p-4 rounded-xl bg-emerald-950/50 border border-emerald-800/80 text-emerald-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    <span className="font-bold text-base text-white">
                      Correct Answer!
                    </span>
                  </div>
                  <span className="text-xs text-emerald-300 font-medium">
                    {autoNextCountdown !== null
                      ? "Loading next question..."
                      : "+1 Streak"}
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-emerald-300/90 mt-1.5 leading-relaxed">
                  {question.explanation}
                </p>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-rose-950/50 border border-rose-800/80 text-rose-200">
                <div className="flex items-center gap-2.5 mb-2">
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  <span className="font-bold text-base text-white">
                    Incorrect — Streak Reset to 0
                  </span>
                </div>

                <div className="text-xs sm:text-sm text-slate-300 mb-2">
                  <span className="font-semibold text-white">Correct Answer: </span>
                  <span className="text-emerald-300 font-medium">
                    {question.options[question.correctAnswerIndex]}
                  </span>
                </div>

                <div className="text-xs sm:text-sm text-slate-300 bg-slate-950/60 p-2.5 rounded-lg border border-slate-800 leading-relaxed">
                  <span className="font-semibold text-slate-400 block text-[11px] uppercase tracking-wider mb-0.5">
                    Explanation
                  </span>
                  {question.explanation}
                </div>
              </div>
            )}

            {/* Next Question Button */}
            <div className="pt-2">
              {/* For wrong answers: user clicks Next Question to proceed */}
              {!isCorrectAnswer && (
                <button
                  type="button"
                  id="next-question-btn"
                  disabled={isGeneratingNext}
                  onClick={onNextQuestion}
                  className="w-full py-4 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 hover:from-blue-500 hover:via-indigo-500 hover:to-purple-500 text-white font-bold text-base sm:text-lg shadow-lg shadow-indigo-900/30 flex items-center justify-center gap-2 transition-all transform active:scale-[0.99] disabled:opacity-60 cursor-pointer"
                >
                  {isGeneratingNext ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Generating Next Question...</span>
                    </>
                  ) : (
                    <>
                      <span>Next Question</span>
                      <ArrowRight className="w-5 h-5" />
                    </>
                  )}
                </button>
              )}

              {/* For correct answers: auto-transitioning, but also allows skipping delay immediately */}
              {isCorrectAnswer && (
                <button
                  type="button"
                  id="skip-to-next-btn"
                  disabled={isGeneratingNext}
                  onClick={onNextQuestion}
                  className="w-full py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-sm flex items-center justify-center gap-2 transition-all cursor-pointer"
                >
                  {isGeneratingNext ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Generating Next Question...</span>
                    </>
                  ) : (
                    <>
                      <span>Continue Immediately</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Quit Quiz Confirmation Modal */}
      {showQuitConfirm && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-sm w-full shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center">
              <h3 className="text-lg font-bold text-white">End Quiz Session?</h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                You'll finish with a current streak of{" "}
                <span className="text-white font-semibold">{stats.currentStreak}</span> and
                a best streak of{" "}
                <span className="text-amber-300 font-semibold">{stats.bestStreak}</span>.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setShowQuitConfirm(false)}
                className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-sm"
              >
                Keep Playing
              </button>
              <button
                type="button"
                id="confirm-quit-btn"
                onClick={() => {
                  setShowQuitConfirm(false);
                  onQuitQuiz();
                }}
                className="py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm"
              >
                View Results
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

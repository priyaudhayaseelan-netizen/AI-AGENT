export type Difficulty = "easy" | "medium" | "hard";

export interface QuizQuestion {
  question: string;
  options: [string, string, string, string] | string[];
  correctAnswerIndex: number;
  explanation: string;
  difficulty: string;
  topic: string;
}

export type ScreenState = "home" | "quiz" | "results";

export interface QuizStats {
  currentStreak: number;
  bestStreak: number;
  totalQuestions: number;
  correctAnswers: number;
}

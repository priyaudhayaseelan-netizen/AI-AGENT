import { useState } from "react";
import { HomeScreen } from "./components/HomeScreen";
import { QuizScreen } from "./components/QuizScreen";
import { ResultsScreen } from "./components/ResultsScreen";
import { LoadingCard } from "./components/LoadingCard";
import { validateQuizQuestion } from "./utils/validation";
import type { QuizQuestion, Difficulty, ScreenState, QuizStats } from "./types";
import { Sparkles, AlertCircle, RefreshCw, Flame } from "lucide-react";

export default function App() {
  const [screenState, setScreenState] = useState<ScreenState>("home");
  const [topic, setTopic] = useState<string>("");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [currentQuestion, setCurrentQuestion] = useState<QuizQuestion | null>(null);
  const [questionNumber, setQuestionNumber] = useState<number>(1);
  const [previousQuestions, setPreviousQuestions] = useState<string[]>([]);
  const [stats, setStats] = useState<QuizStats>({
    currentStreak: 0,
    bestStreak: 0,
    totalQuestions: 0,
    correctAnswers: 0,
  });
  const [bestOverallStreak, setBestOverallStreak] = useState<number>(0);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isGeneratingNext, setIsGeneratingNext] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  // Fetch question from backend API
  const fetchQuestion = async (
    targetTopic: string,
    targetDifficulty: Difficulty,
    askedQuestions: string[]
  ): Promise<QuizQuestion> => {
    const response = await fetch("/api/quiz/generate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        topic: targetTopic,
        difficulty: targetDifficulty,
        previousQuestions: askedQuestions,
      }),
    });

    if (!response.ok) {
      let errorMessage = `Server error (${response.status})`;
      try {
        const errorData = await response.json();
        if (errorData.error) {
          errorMessage = errorData.error;
        }
      } catch {
        // fallback to status
      }
      throw new Error(errorMessage);
    }

    const rawData = await response.json();
    return validateQuizQuestion(rawData);
  };

  // Start new quiz
  const handleStartQuiz = async (selectedTopic: string, selectedDifficulty: Difficulty) => {
    setIsLoading(true);
    setError(null);
    setTopic(selectedTopic);
    setDifficulty(selectedDifficulty);
    setQuestionNumber(1);
    setPreviousQuestions([]);
    setStats({
      currentStreak: 0,
      bestStreak: 0,
      totalQuestions: 0,
      correctAnswers: 0,
    });

    try {
      const firstQ = await fetchQuestion(selectedTopic, selectedDifficulty, []);
      setCurrentQuestion(firstQ);
      setScreenState("quiz");
    } catch (err: unknown) {
      console.error("Quiz start error:", err);
      const msg =
        err instanceof Error
          ? err.message
          : "Could not generate question. Please try again.";
      setError(msg);
      setScreenState("home");
    } finally {
      setIsLoading(false);
    }
  };

  // Submit an answer
  const handleAnswerSubmit = (isCorrect: boolean) => {
    setStats((prev) => {
      const newStreak = isCorrect ? prev.currentStreak + 1 : 0;
      const newBest = Math.max(prev.bestStreak, newStreak);
      if (newBest > bestOverallStreak) {
        setBestOverallStreak(newBest);
      }
      return {
        currentStreak: newStreak,
        bestStreak: newBest,
        totalQuestions: prev.totalQuestions + 1,
        correctAnswers: isCorrect ? prev.correctAnswers + 1 : prev.correctAnswers,
      };
    });
  };

  // Next question
  const handleNextQuestion = async () => {
    if (!currentQuestion) return;

    setIsGeneratingNext(true);
    setError(null);

    const updatedAsked = [...previousQuestions, currentQuestion.question];
    setPreviousQuestions(updatedAsked);

    try {
      const nextQ = await fetchQuestion(topic, difficulty, updatedAsked);
      setCurrentQuestion(nextQ);
      setQuestionNumber((prev) => prev + 1);
    } catch (err: unknown) {
      console.error("Next question error:", err);
      const msg =
        err instanceof Error
          ? err.message
          : "Failed to generate next question. Please retry.";
      setError(msg);
    } finally {
      setIsGeneratingNext(false);
    }
  };

  // Quit Quiz to see Results
  const handleQuitQuiz = () => {
    setScreenState("results");
  };

  // Play Again with same topic and difficulty
  const handlePlayAgain = () => {
    handleStartQuiz(topic, difficulty);
  };

  // Change Topic (back to home)
  const handleChangeTopic = () => {
    setScreenState("home");
    setError(null);
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navbar */}
      <header className="border-b border-slate-800/80 bg-slate-950/70 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          {/* Brand Logo */}
          <button
            type="button"
            onClick={handleChangeTopic}
            className="flex items-center gap-2.5 group cursor-pointer text-left"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 via-indigo-600 to-purple-600 flex items-center justify-center shadow-md shadow-indigo-600/30 group-hover:scale-105 transition-transform">
              <Flame className="w-5 h-5 text-amber-300 fill-amber-300" />
            </div>
            <div>
              <span className="font-extrabold text-base sm:text-lg tracking-tight text-white group-hover:text-indigo-300 transition-colors">
                AI Streak Quiz
              </span>
              <span className="text-[10px] text-slate-400 block -mt-1 font-medium">
                Gemini Generator
              </span>
            </div>
          </button>

          {/* Quick Streak Counter if in Quiz mode */}
          {screenState === "quiz" && (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-950/80 border border-indigo-500/40 text-amber-300 text-xs sm:text-sm font-bold shadow-sm">
                <Flame className="w-4 h-4 fill-amber-300 animate-pulse" />
                <span>Streak: {stats.currentStreak}</span>
              </div>
            </div>
          )}

          {screenState !== "quiz" && bestOverallStreak > 0 && (
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-amber-300 font-semibold bg-amber-500/10 border border-amber-500/30 px-3 py-1 rounded-full">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Record: {bestOverallStreak}</span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center relative">
        {/* Ambient background gradients */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-4xl h-72 bg-gradient-to-b from-indigo-600/10 via-purple-600/5 to-transparent pointer-events-none blur-3xl -z-10" />

        {/* Global Error Banner when in Quiz and Next Question failed */}
        {error && screenState === "quiz" && (
          <div className="max-w-2xl mx-auto px-4 w-full mt-4">
            <div className="p-4 rounded-xl bg-rose-950/70 border border-rose-800 text-rose-200 text-sm flex items-center justify-between gap-3 shadow-lg">
              <div className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />
                <span>{error}</span>
              </div>
              <button
                type="button"
                onClick={handleNextQuestion}
                disabled={isGeneratingNext}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-800 hover:bg-rose-700 text-xs font-bold text-white shrink-0"
              >
                <RefreshCw
                  className={`w-3.5 h-3.5 ${isGeneratingNext ? "animate-spin" : ""}`}
                />
                <span>Retry</span>
              </button>
            </div>
          </div>
        )}

        {/* Screen Routing */}
        {isLoading ? (
          <LoadingCard
            topic={topic}
            difficulty={difficulty}
            questionNumber={questionNumber}
          />
        ) : screenState === "home" ? (
          <HomeScreen
            onStartQuiz={handleStartQuiz}
            isLoading={isLoading}
            error={error}
            onClearError={() => setError(null)}
            bestOverallStreak={bestOverallStreak}
          />
        ) : screenState === "quiz" && currentQuestion ? (
          <QuizScreen
            question={currentQuestion}
            topic={topic}
            difficulty={difficulty}
            stats={stats}
            questionNumber={questionNumber}
            onAnswerSubmit={handleAnswerSubmit}
            onNextQuestion={handleNextQuestion}
            onQuitQuiz={handleQuitQuiz}
            isGeneratingNext={isGeneratingNext}
          />
        ) : screenState === "results" ? (
          <ResultsScreen
            stats={stats}
            topic={topic}
            difficulty={difficulty}
            onPlayAgain={handlePlayAgain}
            onChangeTopic={handleChangeTopic}
          />
        ) : null}
      </main>

      {/* Footer */}
      <footer className="py-4 border-t border-slate-900 text-center text-xs text-slate-500">
        <p>AI Streak Quiz Generator • Powered by Google Gemini</p>
      </footer>
    </div>
  );
}

import type { QuizQuestion } from "../types";

export function validateQuizQuestion(data: unknown): QuizQuestion {
  if (!data || typeof data !== "object") {
    throw new Error("Invalid question format received from server.");
  }

  const q = data as Partial<QuizQuestion>;

  if (typeof q.question !== "string" || !q.question.trim()) {
    throw new Error("Question text is missing or invalid.");
  }

  if (
    !Array.isArray(q.options) ||
    q.options.length !== 4 ||
    !q.options.every((opt) => typeof opt === "string" && opt.trim().length > 0)
  ) {
    throw new Error("Question must contain exactly four non-empty options.");
  }

  if (
    typeof q.correctAnswerIndex !== "number" ||
    !Number.isInteger(q.correctAnswerIndex) ||
    q.correctAnswerIndex < 0 ||
    q.correctAnswerIndex > 3
  ) {
    throw new Error("Correct answer index must be 0, 1, 2, or 3.");
  }

  if (typeof q.explanation !== "string" || !q.explanation.trim()) {
    q.explanation = `The correct answer is "${q.options[q.correctAnswerIndex]}".`;
  }

  return {
    question: q.question.trim(),
    options: q.options.map((opt) => opt.trim()),
    correctAnswerIndex: q.correctAnswerIndex,
    explanation: q.explanation.trim(),
    difficulty: typeof q.difficulty === "string" ? q.difficulty : "medium",
    topic: typeof q.topic === "string" ? q.topic : "General",
  };
}
